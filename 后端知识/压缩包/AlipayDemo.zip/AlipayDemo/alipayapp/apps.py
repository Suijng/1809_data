from django.apps import AppConfig


class AlipayappConfig(AppConfig):
    name = 'alipayapp'
