$(function () {
    var $li=$('.slide_pics li');
    var len=$li.length;//一共有几张图片 循环 动态的看有几个li 图片的数量就出来了
    var $prev=$('.prev')//左按钮
    var $next=$('.next')//右按钮
    var nextli=0; // 将要运动过里的 小圆点几张要点击的第几张
    var nowli=0; //  当前要离开的li
    var timer=null;//定义定时器

    //除了第一个li 都定位到右侧
    $li.not(':first').css({//第一个张最后的位置
        left:1200 // 左侧0 右侧1200
    });

    //动态创建小圆点
    $li.each(function (index) {//each循环 所有图片
        //创建小圆点的li
        var $sli=$('<li></li>');
        //第一个li添加选中的样式
        if(index==0){//index为0的时候是第一张
            $sli.addClass('active');//添加yuandian样式
        }
        //将li添加到ul中
        $sli.appendTo('.yuandian');//加入到ul yuandian里
    });

    $yuandian=$('.yuandian li') ; //获取ul下的所有li
    // alert($yuandian.lengfth);//打印小点的数量

    $yuandian.click(function () {
        //下一个li的索引 下一个将要过来的索引就是当前的这个
        nextli=$(this).index();//获取
        if(nextli==nowli){//一直在点击一张图片时 直接返回
            return;` `
        }
        move();//封装move函数 调用就动
        //小圆点点击 其他的取消选中 添加小圆点样式 删除兄弟的样式
        $(this).addClass('active').siblings().removeClass('active');
    });

    $prev.click(function () {
        nextli--; //越来越小 自减
        move();
        //改变小圆点样式
        $yuandian.eq(nextli).addClass('active').siblings().removeClass('active');
    });

    $next.click(function () {
        nextli++; //越来越大 自增
        move();
        //改变小圆点样式
        $yuandian.eq(nextli).addClass('active').siblings().removeClass('active');
    });

    //鼠标移入停止  鼠标移入清楚定时器 进入子元素不触发
    $('.slide').mouseenter(function () {
        clearInterval(timer);//clear清除循环定时器
    })
    //鼠标移出 在给定时器 也可以简写成hover
    $('.slide').mouseleave(function () {
        timer=setInterval(autoplay,2000);
    })


    //定时器循环自动播放
    timer=setInterval(autoplay,2000); //几秒钟动一次

    //自动播放 逻辑和点击下一张原理一样
    function autoplay() {
        nextli++;
        move();
        //改变圆点样式
        $yuandian.eq(nextli).addClass('active').siblings().removeClass('active');
    }


    function move() {
        //已经走到第一张 继续走的时候 大小于号
        if(nextli<0){
            nextli=len-1;//来的是最后一张
            nowli=0;//要离开是第一张
            $li.eq(nextli).css({left:-1200});//把最后一张定位到左侧 准备进入
            $li.eq(nowli).stop().animate({left:1200});//离开的第一张走到后面
            $li.eq(nextli).stop().animate({left:0});//进入的最后一张走进来
            nowli=nextli;//赋值 当前是就是要离开的
            return;//下边代码正常的 极端的不执行
        }
        //走到最后的
        if(nextli>len-1){
            // alert('111');
            nextli=0;//要来的是第一张
            nowli=len-1;//要离开的是最后一张
            // alert(nowli);
            $li.eq(nextli).css({left:1200});
            $li.eq(nowli).stop().animate({left:-1200});
            $li.eq(nextli).stop().animate({left:0});
            nowli=nextli;
            return;
        }
        // alert('222')

        //小圆点的
        if(nextli>nowli){  //要过来的的大于现在的
            $li.eq(nextli).css({left:1200});//要进来的 样式图片到右边
            //当前张离开
            $li.eq(nowli).stop().animate({left:-1200});//要离开的 到左边-数
        }else{
            $li.eq(nextli).css({left:-1200});//定位到左边 -数
            $li.eq(nowli).stop().animate({left:1200});//要离开的 到右边
        }
        //马上要来的走到0 两个都执行放到下边
        $li.eq(nextli).stop().animate({left:0});//进来的到0
        nowli=nextli;//进来的这张就是要出去的这张
    }
});