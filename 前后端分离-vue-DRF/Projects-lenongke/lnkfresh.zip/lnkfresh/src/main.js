import Vue from 'vue'
import App from './App.vue'
// 引入全局共用css
import '../styles/common.css'
// 引入字体样式
import '../styles/fonts/iconfont.css'
// 全局引入路由配置
import router from './router'
// 引入Mock数据方便测试接口
import '../mock/mock'
// 全局控制状态引入
import store from './store/store'
// 全局加载ajax拦截器
import './axios'


Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
    el: '#app',
    router,
    store,
    components: {App},
    template: '<App/>'
})

