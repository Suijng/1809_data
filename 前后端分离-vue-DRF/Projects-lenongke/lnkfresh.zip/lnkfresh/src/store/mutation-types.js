// 使用常量替代mutation时间类型
export const SET_INFO = 'SET_INFO'

// 获取购物车的数据
export const  SET_SHOPLIST = 'SET_INFO'