export default {
    userInfo: state => {
        return state.userInfo
    },
    goodsList: state => {
        return state.goodsList
    }
}