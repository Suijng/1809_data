import {SET_INFO,SET_SHOPLIST} from './mutation-types'
import cookie from '../../static/js/cookie'
import {getShopCarts} from '../api/api'

export default {
    [SET_INFO] (state) {
        state.userInfo = {
            name:cookie.getCookie('name'),
            token:cookie.getCookie('token')
        }
        window.console.log(state.userInfo)
    },
    [SET_SHOPLIST] (state) {
        if (cookie.getCookie('token') != null){
            getShopCarts().then(response => {
                window.console.log(response.data)
                // 更新store
                state.goodsList.goods_list = response.data
                var totalProice = 0
                response.data.forEach(function (entry) {
                    totalProice += entry.goods.shop_price * entry.nums
                })
                state.goodsList.totalPrice = totalProice
            }).catch(error => {
                window.console.log(error)
            })
        }
    }
}