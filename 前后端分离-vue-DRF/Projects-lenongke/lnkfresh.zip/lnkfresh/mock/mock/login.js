module.exports = {
  msg: '登录成功',
  info: {
    name: 'admin',
  },
  token: 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzINiJ9.eyJlc2VyX21kIjoxLCJ1c2VybmFtZSI6ImFkbWluIiwiZXhwIjoxNTAyMzcSMOk4LCJlbWFpbCI6IjFAMSjb20ifQ.s'
}
