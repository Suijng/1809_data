module.exports = [
  {
    url: '/',
    image: '../../../static/images/banner/banner1.jpg',
    goods: '1'
  },
  {
    url: '/',
    image: '../../../static/images/banner/banner2.jpg',
    goods: '2'
  },
  {
    url: '/',
    image: '../../../static/images/banner/banner3.jpg',
    goods: '3'
  }
]
