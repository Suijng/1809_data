module.exports = [
  {
    'id': 1,
    'keywords': '啤酒'
  },
  {
    'id': 2,
    'keywords': '蔬菜'
  },
  {
    'id': 3,
    'keywords': '牛奶'
  },
  {
    'id': 4,
    'keywords': '水果'
  }
]
