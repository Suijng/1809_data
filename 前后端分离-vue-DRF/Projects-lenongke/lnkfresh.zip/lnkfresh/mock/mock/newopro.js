module.exports = {
  'count': 2,
  'results': [
    {
      id: '654',
      goods_front_image: '../../../static/images/goods/images/20_P_1448946850602.jpg',
      name: '原瓶原装进口洋酒烈酒法国云鹿XO白兰地',
      goods_brief: '[推荐理由]原瓶原装进口洋酒烈酒法国云鹿XO白兰地原瓶原装进口洋酒烈酒法国云鹿XO白兰地原瓶原装进口洋酒烈酒法国云鹿XO白兰地原瓶原装进口洋酒烈酒法国云鹿XO白兰地原瓶原装进口洋酒烈酒法国云鹿XO白兰地原瓶原装进口洋酒烈酒法国云鹿XO白兰地',
      shop_price: '3888',
      market_price: '4666',
      sold_num: 300
    },
    {
      id: '334',
      goods_front_image: '../../../static/images/goods/images/42_P_1448948895193.jpg',
      name: '伊利官方直营全脂营养舒化奶250ml*12盒*2提',
      goods_brief: '伊利官方直营全脂营养舒化奶250ml*12盒*2提伊利官方直营全脂营养舒化奶250ml*12盒*2提伊利官方直营全脂营养舒化奶250ml*12盒*2提伊利官方直营全脂营养舒化奶250ml*12盒*2提伊利官方直营全脂营养舒化奶250ml*12盒*2提伊利官方直营全脂营养舒化奶250ml*12盒*2提',
      shop_price: '66',
      market_price: '88',
      sold_num: 1000
    }
  ]
}
