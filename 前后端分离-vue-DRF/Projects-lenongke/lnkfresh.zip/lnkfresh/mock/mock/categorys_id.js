module.exports = {
  id: 110,
  name: '肉类',
  is_tab: false,
  sub_cat: [
    {
      id: 111,
      name: '精品肉类',
      is_tab: false,
      sub_cat: [
        {
          id: 112,
          name: '羊肉'
        },
        {
          id: 113,
          name: '牛肉'
        },
        {
          id: 114,
          name: '猪肉'
        },
        {
          id: 115,
          name: '鸡肉',
          is_tab: false
        }

      ]
    },
    {
      id: 116,
      name: '海鲜水产',
      sub_cat: [
        {
          id: 117,
          name: '鱼'
        },
        {
          id: 118,
          name: '虾'
        }
      ]
    },
    {
      id: 119,
      name: '精品肉类',
      sub_cat: [
        {
          id: 120,
          name: '羊肉'
        },
        {
          id: 121,
          name: '牛肉'
        },
        {
          id: 122,
          name: '猪肉'
        },
        {
          id: 123,
          name: '鸡肉'
        }

      ]
    },
    {
      id: 124,
      name: '叶菜类',
      sub_cat: [
        {
          id: 125,
          name: '生菜'
        },
        {
          id: 126,
          name: '菠菜'
        },
        {
          id: 127,
          name: '圆椒'
        },
        {
          id: 128,
          name: '西兰花'
        }

      ]
    },
    {
      id: 129,
      name: '叶菜类'
    }
  ]
}
