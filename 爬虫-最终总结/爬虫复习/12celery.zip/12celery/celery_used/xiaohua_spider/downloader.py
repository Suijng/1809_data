# 下载器

import requests

def send_request(url,method="GET",params=None,headers=None,data=None):

    if headers:
        headers = {
            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.80 Safari/537.36'
        }

    if method == 'GET':
        response = requests.get(url=url,params=params,headers=headers)
    elif method == 'POST':
        response = requests.get(url=url,data=data,headers=headers)

    if response.status_code == 200:
        return response.text