### 爬虫主体代码

from xiaohua_spider.downloader import send_request
from xiaohua_spider import app


# 入口方法
@app.task() #实现异步
def start_request(url):
    # 页面源码
    text = send_request(url=url)

def parse
