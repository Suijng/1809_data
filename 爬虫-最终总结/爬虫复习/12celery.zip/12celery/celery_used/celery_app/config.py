# 官方配置文档：查询每个配置项的含义。
# http://docs.celeryproject.org/en/latest/userguide/configuration.html

#broker(消息中间件来接收和发送任务消息)
# BROKER_URL = 'redis://localhost:6379/1'
# 远端
BROKER_URL = 'redis://118.24.255.219:6380/1'
#backend(存储worker执行的结果)
# CELERY_RESULT_BACKEND = 'redis://localhost:6379/2'
# 远端
CELERY_RESULT_BACKEND = 'redis://118.24.255.219:6380/2'

#设置时间参照，不设置默认使用的UTC时间
CELERY_TIMEZONE = 'Asia/Shanghai'
#指定任务的序列化
CELERY_TASK_SERIALIZER='json'
#指定执行结果的序列化
CELERY_RESULT_SERIALIZER='json'


### 定时任务
from datetime import timedelta
from celery.schedules import crontab
## 固定的间隔时间

CELERYBEAT_SXHEDULE = {
    'task1_add':{
        #指定定时发送的任务
        'task':'celery_app.tesk1.add',
        # 指定定时发送任务的时间间隔
        'schedule':timedelta(hours=0,minutes=0,seconds=0.1),
        # 函数参数
        'args':(40,)
    },
    ## 固定每一天的某一个时间发布任务
    'task2_add':{
        'task':'celery_app.tesk1.add',
        'schedule':crontab(hour=14,minute=24),
        'args':(30,)
    }
}



