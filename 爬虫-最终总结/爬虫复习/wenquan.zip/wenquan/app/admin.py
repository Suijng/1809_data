from django.contrib import admin
from .models import *

# Register your models here.

# admin.sites.register(Banner)
# admin.sites.register(Article)
